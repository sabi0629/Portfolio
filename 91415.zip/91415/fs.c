#include  <string.h>
#include  <stdlib.h>
#include  <stdio.h>
#include "fs.h"

unsigned char *fs;
#define N_INODES 100
#define N_BLOCKS 10000
#define BLOCK_SIZE 512
#define N_DIRECTBLOCKS 100
#define NB_FREELIST 1250 // (NBLOCKS/8) rounded up
struct superblock {
	size_t number_of_blocks;
	size_t inode_size;
	size_t inode_number;
};
struct blockk {
	unsigned char data[BLOCK_SIZE];
};
#define UNUSED 0
#define FILE_TYPE 1
#define DIRECTPORY_TYPE 2
#define EMPTY 3
struct inode {
	int direct[N_DIRECTBLOCKS];
	int indirect;
	int directory;
	size_t filesize;
};
struct inodes {
	struct inode inodes[N_INODES];
};
struct freeList {
	unsigned char bitmap[NB_FREELIST];
};

static void FillBlockFlag(unsigned char *bitmap, int idx) {
	bitmap[idx / 8] |= (1u << (idx % 8));
}
static void EmptyBlockFlag(unsigned char *bitmap, int idx) {
	bitmap[idx / 8] &= (1u << (idx % 8)) ^ 0xff;
}
static unsigned int GetBlockFlag(unsigned char *bitmap, int idx) {
	return (bitmap[idx / 8] >> (idx % 8)) & 1U;

}

void mapfs(int fd) {
	if ((fs = mmap(NULL, FSSIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0))
			== NULL) {
		perror("mmap failed");
		exit(EXIT_FAILURE);
	}

}

void unmapfs() {
	munmap(fs, FSSIZE);
}

#define SUPERBLOCK_SECTION 0
#define FREELIST_SECTION 1
#define INODES_SECTION 2
#define BLOCKS_SECTION 3
static unsigned char* getAdress(size_t section) {
	size_t pos = 0;
	if (section == SUPERBLOCK_SECTION)
		return fs + pos;
	pos += sizeof(struct superblock);
	if (section == FREELIST_SECTION)
		return fs + pos;
	pos += sizeof(struct freeList);
	if (section == INODES_SECTION)
		return fs + pos;
	pos += sizeof(struct inodes);
	if (section == BLOCKS_SECTION)
		return fs + pos;
	return NULL;
}
// on linux there is inodeBitmap too
static int getEmptyInode() {
	struct inodes i_nodes;
	memcpy(&i_nodes, getAdress(INODES_SECTION), sizeof(struct inodes));
	for (int i = 0; i < N_INODES; ++i) {
		if (i_nodes.inodes[i].directory == UNUSED)
			return i;
	}
	return -1;

}
static int getEmptyBlock() {
	struct freeList flist;
	memcpy(&flist, getAdress(FREELIST_SECTION), sizeof(struct freeList));
	int size = sizeof(flist.bitmap);
	for (int i = 0; i < size * 8; ++i)
		if (GetBlockFlag(flist.bitmap, i) == 0u)
			return i;
	return -1;

}
static struct inode* getNodeAdress(int idx) {
	return (struct inode*) (getAdress(INODES_SECTION)
			+ sizeof(struct inode) * idx);

}
static struct blockk* getBlockAdress(int idx) {
	return (struct blockk*) (getAdress(BLOCKS_SECTION)
			+ sizeof(struct blockk) * idx);
}

void loadfs() {

}
void formatfs() {
	struct superblock sblock;
	sblock.number_of_blocks = N_BLOCKS;
	sblock.inode_size = BLOCK_SIZE;
	sblock.inode_number = N_INODES;

	struct freeList flist;
	int size = sizeof(flist.bitmap);
	for (int i = 0; i < size * 8; ++i)
		EmptyBlockFlag(flist.bitmap, i);

	struct inodes i_nodes;
	for (int i = 0; i < N_INODES; ++i) {
		for (int ii = 0; ii < N_DIRECTBLOCKS; ++ii)
			i_nodes.inodes[i].direct[ii] = 0;
		i_nodes.inodes[i].indirect = 0;
		i_nodes.inodes[i].directory = UNUSED;
		i_nodes.inodes[i].filesize = 0;
	}
	size_t pos = 0;
	memcpy(fs + pos, &sblock, sizeof(struct superblock));
	pos += sizeof(struct superblock);
	memcpy(fs + pos, &flist, sizeof(struct freeList));
	pos += sizeof(struct freeList);
	memcpy(fs + pos, &i_nodes, sizeof(struct inodes));
	pos += sizeof(struct inodes);

	// add root node

	struct inode *inode2 = getNodeAdress(0);
	inode2->directory = DIRECTPORY_TYPE;

	int block2 = getEmptyBlock();
	if (block2 == -1) {
		printf("Full disk\n");
		return;
	}
	struct blockk *blockstruct = getBlockAdress(block2);
	strcpy(blockstruct->data, "/;0;");
	struct freeList *flist1 = (struct freeList*) getAdress(FREELIST_SECTION);
	FillBlockFlag(flist1->bitmap, block2);
	inode2->direct[0] = block2;
	inode2->filesize = strlen(blockstruct->data);

}


static int fileExists(int nblock, char *fname) {
	struct blockk *blockstruct = getBlockAdress(nblock);

	char parts[200][80];
	int nPart = 0;
	char *str;
	char data[512];
	strcpy(data, blockstruct->data);

	str = strtok(data, ";");
	while (str != NULL) {
		strcpy(parts[nPart], str);
		nPart++;
		str = strtok(NULL, ";");
	}
	for (int i = 2; i < nPart; i += 2) {
		if (strcmp(parts[i], fname) == 0) {
			return atoi(parts[i + 1]);
		}
	}
	return 0;
}

static void printDirContent(int nblock, int ii) {

	struct blockk *blockstruct = getBlockAdress(nblock);

	char parts[200][80];
	int nPart = 0;
	char *str;
	char data[512];
	strcpy(data, blockstruct->data);

	str = strtok(data, ";");
	while (str != NULL) {
		strcpy(parts[nPart], str);
		nPart++;
		str = strtok(NULL, ";");
	}
	for (int i = 2; i < nPart; i += 2) {
		printf(" '%s' %s\n", parts[i], parts[i + 1]);
	}
	return;
}

static void LsPrintDirContent(int nblock, int ii) {

	struct blockk *blockstruct = getBlockAdress(nblock);

	char parts[200][80];
	int nPart = 0;
	char *str;
	char data[512];
	strcpy(data, blockstruct->data);

	str = strtok(data, ";");
	while (str != NULL) {
		strcpy(parts[nPart], str);
		nPart++;
		str = strtok(NULL, ";");
	}
	for (int i = 2; i < nPart; i += 2) {
		for (int cc = 0; cc <= ii; ++cc)
			printf("-");
		printf("%s\n", parts[i]);
	}
	return;
}

static int countfiles(int nblock) {
	struct blockk *blockstruct = getBlockAdress(nblock);

	char data[512];
	strcpy(data, blockstruct->data);

	char parts[200][80];
	int nPart = 0;
	char *str;
	str = strtok(data, ";");
	while (str != NULL) {
		strcpy(parts[nPart], str);
		//printf("part:%s\n", parts[nPart]);
		nPart++;
		str = strtok(NULL, ";");
	}
	return (nPart / 2) - 1;
}

// inode1->filesize = this
static int addFileToBlock(int nblock, char *fname, int inode) {
	struct blockk *blockstruct = getBlockAdress(nblock);
	strcat(blockstruct->data, fname);
	strcat(blockstruct->data, ";");
	char nmbr[100];
	sprintf(nmbr, "%d;", inode);
	strcat(blockstruct->data, nmbr);
	return strlen(blockstruct->data);

}
static int removeFileInBlock(int nblock, char *fname) {
	struct blockk *blockstruct = getBlockAdress(nblock);
	char parts[200][80];
	char data[512];
	strcpy(data,blockstruct->data);
	int nPart = 0;
	char *str;
	str = strtok(data, ";");
	while (str != NULL) {
		strcpy(parts[nPart], str);
		//printf("part:%s\n", parts[nPart]);
		nPart++;
		str = strtok(NULL, ";");
	}
	int idx = 0;
	strcpy(blockstruct->data, "");
	for (int i = 0; i < nPart; i += 2) {
		if (strcmp(parts[i], fname) == 0) {
			//
		} else {
			strcat(blockstruct->data, parts[i]);
			strcat(blockstruct->data, ";");
			strcat(blockstruct->data, parts[i + 1]);
			strcat(blockstruct->data, ";");
		}
	}

	return strlen(blockstruct->data);

}
static int createFile(int inode, int block, char *fname) {

	struct freeList *flist = (struct freeList*) getAdress(FREELIST_SECTION);
	struct inode *inode1 = getNodeAdress(inode);

	//---------- add indirect block ------------
	inode1->indirect = getEmptyBlock();
	struct blockk *blockstruct1 = getBlockAdress(inode1->indirect);

	struct inode *indirectInode = (struct inode*)blockstruct1;
	FillBlockFlag(flist->bitmap, inode1->indirect);
	for (int ii = 0; ii < N_DIRECTBLOCKS; ++ii)
		indirectInode->direct[ii] = 0;
	//----------------------------------------------
	struct blockk *blockstruct = getBlockAdress(block);
	FILE *file;
	file = fopen(fname, "rb");
	if (file == NULL) {
		printf("fopen failed\n");
		return -1;
	}
	int cnt = 0;
	int cntBlock=0;
	int cblock=block;
	int directIdx=0;
	int directIdx2=0;

	while (!feof(file)) {
		int c; // sould be int not char
		c = fgetc(file);
		if (feof(file)) {
			break;
		}

		blockstruct->data[cntBlock] = c;
		++cntBlock;
		if(directIdx<99 && cntBlock>=512){
			directIdx++;
			//printf("directIdx %d cntBlock %d cnt %d\n",directIdx,cntBlock,cnt);

			inode1->direct[directIdx] = getEmptyBlock();
			//printf("emptyblock:%d\n",inode1->direct[directIdx] );
			if (inode1->direct[directIdx]  == -1) {
				printf("Full disk-\n");
				return -1;
			}
			FillBlockFlag(flist->bitmap, inode1->direct[directIdx]);
			blockstruct = getBlockAdress(inode1->direct[directIdx]);
			cntBlock=0;
		}else  if(directIdx>=99 && cntBlock>=512){
			indirectInode->direct[directIdx2] = getEmptyBlock();
			//printf("directIdx2 %d cntBlock %d cnt %d\n",directIdx2,cntBlock,cnt);
			//printf("emptyblock_indirect:%d\n",indirectInode->direct[directIdx2] );
			if (indirectInode->direct[directIdx2]  == -1) {
				printf("Full disk-\n");
				return -1;
			}
			FillBlockFlag(flist->bitmap, indirectInode->direct[directIdx2]);
			blockstruct = getBlockAdress(indirectInode->direct[directIdx2]);
			directIdx2++;
			cntBlock=0;
		}
				++cnt;
	}
	inode1->filesize = cnt;
	inode1->directory = FILE_TYPE;
	printf("File added, file size : %d\n", cnt);
	return cnt;

}
static void AddFile(char *fname, int inode, char tokens[][80], int ntoken, int i) {

	struct freeList *flist = (struct freeList*) getAdress(FREELIST_SECTION);
	struct inode *inode1 = getNodeAdress(inode);

	int block = inode1->direct[0];
	//printf("AddFile fname %s inode:%d i:%d block:%d ntoken %d \n", fname, inode,
	//		i, block, ntoken);
	struct blockk *blockstruct = getBlockAdress(block);
	//if not file
	if (i != ntoken) {

		int exist = fileExists(block, tokens[i]);

		if (exist > 0) {
			AddFile(tokens[i], exist, tokens, ntoken, i + 1);
		} else {
			int I = getEmptyInode();
			if (I == -1) {
				printf("Full disk\n");
				return;
			}
			struct inode *inode2 = getNodeAdress(I);
			inode2->directory = DIRECTPORY_TYPE;

			int block2 = getEmptyBlock();
			if (block2 == -1) {
				printf("Full disk\n");
				return;
			}
			FillBlockFlag(flist->bitmap, block2);
			inode2->direct[0] = block2;
			struct blockk *blockstruct2 = getBlockAdress(block2);
			strcpy(blockstruct2->data, tokens[i]);
			strcat(blockstruct2->data, ";0;");
			inode2->filesize = strlen(blockstruct2->data);

			AddFile(tokens[i], I, tokens, ntoken, i + 1);

			inode1->filesize = addFileToBlock(block, tokens[i], I);

		}

	} else {
		inode1->directory = FILE_TYPE;
		int size = createFile(inode, block, fname);
		if (size == -1)
			return;
		inode1->filesize = size;
	}

}
static void printFileContent(int inode, int ii) {


	struct inode *inode1 = getNodeAdress(inode);
	struct blockk *blockstruct1 = getBlockAdress(inode1->indirect);
	struct inode *indirectInode = (struct inode*)blockstruct1;
	int b = inode1->direct[0];
	int sz = inode1->filesize;
	struct blockk *blockstruct = getBlockAdress(b);
	int directIdx=0;
	int directIdx2=0;
	int cntBlock=0;
	for (int ii = 0; ii < sz; ++ii) {

		//printf("%c", blockstruct->data[cntBlock]);
		++cntBlock;
		if(directIdx<99 && cntBlock>=512){
			directIdx++;
			blockstruct = getBlockAdress(inode1->direct[directIdx]);
			cntBlock=0;
		}if(directIdx>=99 && cntBlock>=512){
			blockstruct = getBlockAdress(indirectInode->direct[directIdx2]);
			directIdx2++;
			cntBlock=0;
		}
	}

}
static void printFiles(char *fname, int inode, char tokens[][80], int ntoken, int i) {

	struct freeList *flist = (struct freeList*) getAdress(FREELIST_SECTION);
	struct inode *inode1 = getNodeAdress(inode);

	int block = inode1->direct[0];
	struct blockk *blockstruct = getBlockAdress(block);
	//if not file

	if (i != ntoken) {

		int exist = fileExists(block, tokens[i]);

		if (exist > 0) {
			int cnt= countfiles(block);

			if(cnt>0)
				printf("directory '%s':\n", fname);
			else
				printf("Empty directory '%s':\n", fname);
			printDirContent(block, i);
			printFiles(tokens[i], exist, tokens, ntoken, i + 1);
		}
	} else {
		printf("file '%s':\n", fname);
		//printFileContent(inode,i);

	}

}
static void removeFiles(char *fname, int inode, char tokens[][80], int ntoken, int i) {

	struct freeList *flist = (struct freeList*) getAdress(FREELIST_SECTION);
	struct inode *inode1 = getNodeAdress(inode);

	int block = inode1->direct[0];
	struct blockk *blockstruct = getBlockAdress(block);
	//if not file
	if (i != ntoken) {



		int exist = fileExists(block, tokens[i]);

		if (exist > 0) {
			if(i!=0)inode1->directory = UNUSED;

			inode1->filesize = removeFileInBlock(block, tokens[i]);

			removeFiles(tokens[i], exist, tokens, ntoken, i + 1);
		}
	} else {
		inode1->directory = UNUSED;
		inode1->filesize = 0;
		printf("file '%s':\n", fname);
		for (int ii = 0; ii < N_DIRECTBLOCKS; ++ii)
		{
			if(inode1->direct[ii]!=0)
				EmptyBlockFlag(flist->bitmap , inode1->direct[ii]);
			inode1->direct[ii] = 0;
			if(inode1->indirect!=0){
				struct blockk *blockstruct1 = getBlockAdress(inode1->indirect);
				struct inode *indirectInode = (struct inode*)blockstruct1;
				for (int ii1 = 0; ii1 < N_DIRECTBLOCKS; ++ii1)
				{
					if(indirectInode->direct[ii]!=0)
						EmptyBlockFlag(flist->bitmap , inode1->direct[ii]);

				}
			}

		}
		if(inode1->indirect!=0)
			EmptyBlockFlag(flist->bitmap,inode1->indirect );
		inode1->indirect = 0;

	}

}

static void lsFiles(char *fname, int inode,int i) {

	if(i==0)printf("/\n");
	struct freeList *flist = (struct freeList*) getAdress(FREELIST_SECTION);
	struct inode *inode1 = getNodeAdress(inode);

	int block = inode1->direct[0];
	struct blockk *blockstruct = getBlockAdress(block);
	if(inode1->directory==DIRECTPORY_TYPE)
	{
		int cnt= countfiles(block);

		if(cnt>0){
			char parts[200][80];
			int nPart = 0;
			char *str;
			char data[512];
			strcpy(data, blockstruct->data);

			str = strtok(data, ";");
			while (str != NULL) {
				strcpy(parts[nPart], str);
				nPart++;
				str = strtok(NULL, ";");
			}
			for (int ic = 2; ic < nPart; ic += 2) {
				for (int cc = 0; cc <= i; ++cc)
					printf("-");
				printf("+ %s \n", parts[ic]);
				lsFiles(parts[ic], atoi(parts[ic+1]), i + 1);

			}
		}

	}
}

static void extractFiles(char *fname, int inode, char tokens[][80], int ntoken, int i) {

	struct freeList *flist = (struct freeList*) getAdress(FREELIST_SECTION);
	struct inode *inode1 = getNodeAdress(inode);

	int block = inode1->direct[0];
	struct blockk *blockstruct = getBlockAdress(block);
//if not file

	if (i != ntoken) {

		int exist = fileExists(block, tokens[i]);

		if (exist > 0) {
			extractFiles(tokens[i], exist, tokens, ntoken, i + 1);
		}
	} else {
		printFileContent(inode, i);
	}

}


void addfilefs(char *fname) {
	char tokens[200][80];
	size_t ntoken = 0;
	char *str;

	str = strtok(fname, "/");
	while (str != NULL) {
		strcpy(tokens[ntoken], str);
		//printf("part:%s\n", tokens[ntoken]);
		ntoken++;
		str = strtok(NULL, "/");
	}

	AddFile("/", 0, tokens, ntoken, 0);
}

void removefilefs(char *fname) {
	char tokens[200][80];
	size_t ntoken = 0;
	char *str;

	str = strtok(fname, "/");
	while (str != NULL) {
		strcpy(tokens[ntoken], str);
		//printf("part:%s\n", tokens[ntoken]);
		ntoken++;
		str = strtok(NULL, "/");
	}

	removeFiles("/", 0, tokens, ntoken, 0);
}

void extractfilefs(char *fname) {
	char tokens[200][80];
	size_t ntoken = 0;
	char *str;

	str = strtok(fname, "/");
	while (str != NULL) {
		strcpy(tokens[ntoken], str);
		ntoken++;
		str = strtok(NULL, "/");
	}

	extractFiles("/", 0, tokens, ntoken, 0);

}
void extractfile1(char *fname) {
	struct inodes i_nodes;
	memcpy(&i_nodes, getAdress(INODES_SECTION), sizeof(struct inodes));
	for (int i = 0; i < N_INODES; ++i) {
		if (i_nodes.inodes[i].directory != UNUSED) {

			int b = i_nodes.inodes[i].direct[0];
			int sz = i_nodes.inodes[i].filesize;
			struct blockk *blockstruct = getBlockAdress(b);

			printf("\ni:%d\n", i);
			for (int ii = 0; ii < sz; ++ii) {
				if (i_nodes.inodes[i].directory == DIRECTPORY_TYPE) printf("%c", blockstruct->data[ii]);
			}

		}
	}

}

void debug(char *fname) {
	char tokens[200][80];
	size_t ntoken = 0;
	char *str;

	str = strtok(fname, "/");
	while (str != NULL) {
		strcpy(tokens[ntoken], str);
		ntoken++;
		str = strtok(NULL, "/");
	}

	printFiles("/", 0, tokens, ntoken, 0);

}
void lsfs() {
	lsFiles("/",0,0);
}
